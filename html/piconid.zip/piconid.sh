#/bin/sh
sqlite3 /var/db.dat \
  'select fullname, service_type, service_id, c.ts_id, c.org_network_id, angle, frequency, polarization
   from channelinfo c, satinfo s, tpinfo t
   where c.sat_id = s.id AND tp_id = t.id
   order by s.id, frequency, polarization, service_id' |\
awk -F'|' '{
  if ($8=='0') {pol="H"} else {pol="V"}
  if ($6<0) {ew="W"} else {ew="E"}
  angle=sqrt($6*$6)/10
  printf("%s%s %s%s %s", angle, ew, $7, pol)
  printf("1_0_%X_%X_%X_%X_%X0000_0_0_0.png ", $2, $3, $4, $5, $6)
  print $1}'
